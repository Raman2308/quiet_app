import 'package:dartz/dartz.dart';
import '../errors/failures.dart';
import '../errors/failure_mapper.dart';

import '../logger/logger.dart';
abstract class BaseRepository {
  final Logger logger;
   BaseRepository(this.logger);
  Future<Either<Failure, T>> executeSafely<T>(
    Future<T> Function() action, {
    String? methodName,
    Map<String, dynamic>? data,
  }) async {
    try {
      final result = await action();

      return Right(result);
    } catch (e, stackTrace) {
  
    logger.error("error");
      return Left(FailureMapper.mapException(e, stackTrace));
    }
  }
}