abstract class Logger {
  void info(String message);

  void error(
    String message, {
    Object? error,
    StackTrace? stackTrace,
  });
}