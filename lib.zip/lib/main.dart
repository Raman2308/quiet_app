import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'features/auth/data/auth_repository_impl.dart';
import 'features/auth/presentation/controllers/auth_controller.dart';
import 'app/app.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:app_quiet/core/logger/app_logger.dart';
import 'package:app_quiet/core/logger/console_logger.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // initialize a concrete logger so AppLogger static helpers can be used
  final systemLogger = ConsoleLogger();
  AppLogger.initialize(systemLogger);

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e, st) {
    AppLogger.appError(e.toString(), error: e, stackTrace: st);
    rethrow;
  }

  // 2️⃣ Then create instances
  final logger = AppLogger();
  final firebaseAuth = FirebaseAuth.instance;
  final firestore = FirebaseFirestore.instance;

  // 3️⃣ Dependency injection
  final authRepository = AuthRepositoryImpl(firebaseAuth, firestore, logger);

  final authController = AuthController(authRepository);

  runApp(QuietApp(authController: authController));
}
