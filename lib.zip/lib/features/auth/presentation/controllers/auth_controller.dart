import 'package:app_quiet/features/auth/domain/repositories/auth_repository.dart';
import 'package:app_quiet/features/auth/domain/usecases/login_usecase.dart';
import 'package:flutter/foundation.dart';

class AuthController extends ChangeNotifier {
  final AuthRepository repository;
  late final LoginUseCase loginUseCase;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  AuthController(this.repository) {
    loginUseCase = LoginUseCase(repository);
  }

  Future<void> login({required String email, required String password}) async {
    _isLoading = true;
    notifyListeners();

    try {
      await loginUseCase(email: email, password: password);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
